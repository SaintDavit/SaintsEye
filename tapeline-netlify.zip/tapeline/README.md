# Tapeline

Static front-end (public/) plus three Netlify Functions (netlify/functions/).

## Deploy
1. Push this folder to a GitHub repo, then in Netlify choose Add new site > Import an existing project.
   (Or run `npx netlify-cli deploy --prod` from this folder.) No build command is needed.
2. In Site settings > Environment variables add:
   - ANTHROPIC_API_KEY  (required for headline tags, explanations and symbol impact)
   - CLAUDE_MODEL       (optional, default claude-haiku-5-5)
   - NEWS_FEEDS         (optional, comma-separated RSS URLs to replace the defaults)
3. Redeploy. Open the site.

## Data sources (all free, all unofficial or public)
- Prices: Yahoo Finance chart endpoint (NQ=F, ES=F, YM=F, GC=F and FX). CME futures are delayed.
- News: public RSS feeds (Fed, CNBC, FXStreet), classified by Claude.
- Calendar: Forex Factory weekly JSON export (forecast and previous only, no actuals).
