const Y={NQ:"NQ=F",ES:"ES=F",YM:"YM=F",GOLD:"GC=F",EURUSD:"EURUSD=X",GBPUSD:"GBPUSD=X",USDJPY:"USDJPY=X",AUDUSD:"AUDUSD=X",USDCAD:"USDCAD=X",USDCHF:"USDCHF=X",NZDUSD:"NZDUSD=X"};
const TF={"5m":["5d","5m"],"15m":["1mo","15m"],"1h":["3mo","60m"],"1d":["1y","1d"]};
const C=new Map();
const cached=async(k,ttl,fn)=>{const e=C.get(k);if(e&&Date.now()-e.t<ttl)return e.v;const v=await fn();C.set(k,{t:Date.now(),v});return v};
async function candles(sym,range,interval){
  const r=await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${Y[sym]}?range=${range}&interval=${interval}`,{headers:{"User-Agent":"Mozilla/5.0"}});
  if(!r.ok)throw new Error("Yahoo "+r.status);
  const c=(await r.json()).chart.result[0],q=c.indicators.quote[0];
  return c.timestamp.map((t,i)=>({time:t,open:q.open[i],high:q.high[i],low:q.low[i],close:q.close[i]})).filter(x=>x.close!=null&&x.open!=null);
}
const at=(c,ts)=>{let r=c[0];for(const x of c){if(x.time<=ts)r=x;else break}return r.close};
const J=(o,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{"content-type":"application/json","cache-control":"public, max-age=20"}});
export default async(req)=>{
  try{
    const u=new URL(req.url),sym=u.searchParams.get("sym");
    if(sym){
      if(!Y[sym])return J({error:"unknown symbol"},400);
      const [rg,iv]=TF[u.searchParams.get("tf")]||TF["5m"];
      return J({candles:await cached(`${sym}${rg}${iv}`,20000,()=>candles(sym,rg,iv))});
    }
    const rows=await cached("rows",25000,()=>Promise.all(Object.keys(Y).map(async k=>{
      const c=await candles(k,"5d","5m"),l=c.at(-1),ch=s=>(l.close/at(c,l.time-s)-1)*100;
      return{k,last:l.close,m15:ch(900),h1:ch(3600),d1:ch(86400)};
    })));
    return J({rows,t:Date.now()});
  }catch(e){return J({error:String(e.message||e)},502)}
};
export const config={path:"/api/market"};
