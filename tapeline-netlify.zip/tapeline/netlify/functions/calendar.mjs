const CUR=["USD","EUR","GBP","JPY","AUD","CAD","CHF","NZD"];
let cache=null;
export default async()=>{
  try{
    if(!cache||Date.now()-cache.t>600000){
      const r=await fetch("https://nfs.faireconomy.media/ff_calendar_thisweek.json",{headers:{"User-Agent":"Mozilla/5.0"}});
      if(!r.ok)throw new Error("calendar "+r.status);
      const d=await r.json();
      cache={t:Date.now(),v:d.filter(e=>CUR.includes(e.country)&&["High","Medium"].includes(e.impact)).map(e=>{
        const inv=/unemploy|claims/i.test(e.title),hi=inv?"Below forecast":"Above forecast",lo=inv?"Above forecast":"Below forecast",c=e.country;
        const pb=c==="USD"?`${hi}: USD firmer, gold and equity indices usually softer. ${lo}: the reverse.`:`${hi}: ${c} firmer against the dollar. ${lo}: ${c} softer.`;
        return{t:new Date(e.date).getTime(),c,n:e.title,imp:e.impact,f:e.forecast||"",p:e.previous||"",pb};
      }).sort((a,b)=>a.t-b.t)};
    }
    return new Response(JSON.stringify(cache.v),{headers:{"content-type":"application/json"}});
  }catch(e){return new Response(JSON.stringify({error:String(e.message||e)}),{status:502,headers:{"content-type":"application/json"}})}
};
export const config={path:"/api/calendar"};
