const FEEDS=(process.env.NEWS_FEEDS||"https://www.federalreserve.gov/feeds/press_all.xml,https://www.cnbc.com/id/100003114/device/rss/rss.html,https://www.cnbc.com/id/20910258/device/rss/rss.html,https://www.fxstreet.com/rss/news").split(",");
const SYS=`You analyse financial headlines for futures and FX traders. Input: JSON array of {i,h}. Output: a JSON array only, no prose or markdown, one object per input: {"i":number,"relevant":boolean (true only if it could move US indices, gold or major FX),"a":"Fed"|"Data"|"Trump"|"Geopolitics"|"Other","tag":"2-3 word read such as Hawkish, Dovish, Hot inflation, Risk-off, Risk-on","why":"one plain-English sentence on why markets react","imp":{SYMBOL:integer -2..2}}. SYMBOL is one of NQ,ES,YM,GOLD,EURUSD,GBPUSD,USDJPY,AUDUSD,USDCAD,USDCHF,NZDUSD and the number is the expected direction of that symbol's own price (for USDJPY, +1 means USDJPY rises). Omit symbols with no expected impact.`;
const tag=(x,t)=>{const m=x.match(new RegExp(`<${t}[^>]*>([\\s\\S]*?)</${t}>`));return m?m[1].replace(/<!\[CDATA\[|\]\]>/g,"").replace(/<[^>]+>/g,"").replace(/&amp;/g,"&").replace(/&#8217;|&apos;/g,"’").replace(/&quot;/g,'"').trim():""};
const seen=new Map();let last=null;
async function feed(u){
  try{
    const r=await fetch(u,{headers:{"User-Agent":"Mozilla/5.0"}});if(!r.ok)return[];
    const src=new URL(u).hostname.replace("www.","");
    return(await r.text()).split(/<item[ >]/).slice(1).map(x=>({src,title:tag(x,"title"),link:tag(x,"link"),t:Date.parse(tag(x,"pubDate"))||Date.now()})).filter(n=>n.title);
  }catch{return[]}
}
async function classify(list){
  const key=process.env.ANTHROPIC_API_KEY;if(!key||!list.length)return;
  const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"content-type":"application/json","x-api-key":key,"anthropic-version":"2023-06-01"},
    body:JSON.stringify({model:process.env.CLAUDE_MODEL||"claude-haiku-5-5",max_tokens:4000,system:SYS,messages:[{role:"user",content:JSON.stringify(list.map((n,i)=>({i,h:n.title})))}]})});
  const d=await r.json(),txt=(d.content||[]).map(b=>b.text||"").join("").replace(/```json|```/g,"").trim();
  for(const o of JSON.parse(txt)){const n=list[o.i];if(n)seen.set(n.title,{relevant:!!o.relevant,a:o.a,tag:o.tag,why:o.why,imp:o.imp||{}})}
}
export default async()=>{
  try{
    if(!last||Date.now()-last.t>60000){
      const all=(await Promise.all(FEEDS.map(feed))).flat().sort((a,b)=>b.t-a.t),dedup=[...new Map(all.map(n=>[n.title,n])).values()].slice(0,30);
      await classify(dedup.filter(n=>!seen.has(n.title)));
      last={t:Date.now(),v:{classified:!!process.env.ANTHROPIC_API_KEY,items:dedup.map(n=>({...n,...(seen.get(n.title)||{relevant:false})})).filter(n=>n.relevant).slice(0,25)}};
    }
    return new Response(JSON.stringify(last.v),{headers:{"content-type":"application/json"}});
  }catch(e){return new Response(JSON.stringify({error:String(e.message||e)}),{status:502,headers:{"content-type":"application/json"}})}
};
export const config={path:"/api/news"};
