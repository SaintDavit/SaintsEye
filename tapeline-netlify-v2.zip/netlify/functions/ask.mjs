const SYS="You are a markets analyst inside a news-trading dashboard covering NQ, ES, YM, gold and major FX pairs. Answer in plain English in under 120 words, using the supplied context first. Explain why markets move and what to watch. Never give price predictions, entry points or trade instructions; describe what each scenario would likely mean instead.";
const J=(o,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{"content-type":"application/json"}});
let n=0,w=Date.now();
export default async(req)=>{
  try{
    if(req.method!=="POST")return J({error:"POST only"},405);
    if(Date.now()-w>36e5){n=0;w=Date.now()}
    if(++n>30)return J({error:"Hourly question limit reached. Try again later."},429);
    const key=process.env.ANTHROPIC_API_KEY;if(!key)return J({error:"ANTHROPIC_API_KEY is not set"},500);
    const{q,ctx}=await req.json();
    const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"content-type":"application/json","x-api-key":key,"anthropic-version":"2023-06-01"},
      body:JSON.stringify({model:process.env.CLAUDE_MODEL||"claude-haiku-5-5",max_tokens:500,system:SYS,messages:[{role:"user",content:`Context:\n${String(ctx||"").slice(0,4000)}\n\nQuestion: ${String(q||"").slice(0,500)}`}]})});
    const d=await r.json();
    return J({answer:(d.content||[]).map(b=>b.text||"").join("")||d.error?.message||"No answer"});
  }catch(e){return J({error:String(e.message||e)},502)}
};
export const config={path:"/api/ask"};
