const CUR=["USD","EUR","GBP","JPY","AUD","CAD","CHF","NZD"];
const BASE={
USD:[["GOLD",-1],["NQ",-1],["ES",-1],["EURUSD",-1],["USDJPY",1]],
EUR:[["EURUSD",1],["GBPUSD",1],["USDCHF",-1],["GOLD",1],["USDJPY",-1]],
GBP:[["GBPUSD",1],["EURUSD",1],["USDCHF",-1],["GOLD",1],["USDJPY",-1]],
JPY:[["USDJPY",-1],["NQ",-1],["ES",-1],["GOLD",1],["USDCHF",-1]],
AUD:[["AUDUSD",1],["NZDUSD",1],["GOLD",1],["NQ",1],["ES",1]],
CAD:[["USDCAD",-1],["AUDUSD",1],["NZDUSD",1],["GOLD",1],["ES",1]],
CHF:[["USDCHF",-1],["GOLD",1],["USDJPY",-1],["ES",-1],["NQ",-1]],
NZD:[["NZDUSD",1],["AUDUSD",1],["GOLD",1],["USDCAD",-1],["ES",1]]};
const cat=t=>/unemploy|claims/i.test(t)?"inv":/CPI|PPI|PCE|inflation|price/i.test(t)?"inf":/GDP|retail|PMI|ISM|sales|production|confidence|housing|orders|trade balance/i.test(t)?"gro":/rate|statement|press conf|minutes|speaks|speech|FOMC|MPC|governor|chair/i.test(t)?"cb":"gen";
function scen(c,title){
  const k=cat(title);let up=BASE[c].map(x=>[...x]);
  if(k==="gro"&&c==="USD")up.forEach(x=>{if(x[0]==="NQ"||x[0]==="ES")x[1]=1});
  if(k==="inv")up.forEach(x=>x[1]*=-1);
  const [hl,ll]=k==="cb"?["More hawkish","More dovish"]:["Above forecast","Below forecast"];
  return{up,hl,ll,pb:`${hl}: ${up.slice(0,3).map(([s,d])=>s+(d>0?" up":" down")).join(", ")}. ${ll}: the reverse.`};
}
let cache=null;
export default async()=>{
  try{
    if(!cache||Date.now()-cache.t>600000){
      const r=await fetch("https://nfs.faireconomy.media/ff_calendar_thisweek.json",{headers:{"User-Agent":"Mozilla/5.0"}});
      if(!r.ok)throw new Error("calendar "+r.status);
      const d=await r.json();
      cache={t:Date.now(),v:d.filter(e=>CUR.includes(e.country)&&["High","Medium"].includes(e.impact)).map(e=>({t:new Date(e.date).getTime(),c:e.country,n:e.title,imp:e.impact,f:e.forecast||"",p:e.previous||"",...scen(e.country,e.title)})).sort((a,b)=>a.t-b.t)};
    }
    return new Response(JSON.stringify(cache.v),{headers:{"content-type":"application/json"}});
  }catch(e){return new Response(JSON.stringify({error:String(e.message||e)}),{status:502,headers:{"content-type":"application/json"}})}
};
export const config={path:"/api/calendar"};
